const ViewRoutes = () => {
  return (
    <div>ViewRoutes</div>
  )
}

export default ViewRoutes